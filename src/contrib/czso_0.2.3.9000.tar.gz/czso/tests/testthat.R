library(testthat)
library(czso)

test_check("czso")
