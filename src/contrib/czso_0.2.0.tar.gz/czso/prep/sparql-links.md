http://www.iro.umontreal.ca/~lapalme/ift6281/sparql-1_1-cheat-sheet.pdf
https://www.youtube.com/watch?v=FvGndkpa4K0
https://en.wikibooks.org/wiki/SPARQL/
