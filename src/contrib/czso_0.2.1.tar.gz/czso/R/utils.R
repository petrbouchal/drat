ua_header <- c("User-Agent" = "github.com/petrbouchal/czso")
ua_string <- "github.com/petrbouchal/czso"
