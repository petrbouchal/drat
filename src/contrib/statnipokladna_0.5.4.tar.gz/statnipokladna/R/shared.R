sp_base_url <- "http://monitor.statnipokladna.cz"
usr <- "github.com/petrbouchal/statnipokladna"
