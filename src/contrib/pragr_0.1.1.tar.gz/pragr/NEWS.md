# pragr 0.1.1

* improved file handling in raster data functions
* improved sizing in prg_basemap()
* streamlined interface to existing map services in raster functions

# pragr 0.1.0

* new raster data functions

# pragr 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
* basic project infrastructure
* added a `verbose` parameter to prg_*()
