#' Prague RUIAN code
#'
#' Prague RUIAN code
#'
#' @format character verctor of length 1
#' \describe{
#'   Prague RUIAN code
#' }
#' @export
"prg_kod"
prg_kod <- '554782'
usethis::use_data(prg_kod, overwrite = T)
