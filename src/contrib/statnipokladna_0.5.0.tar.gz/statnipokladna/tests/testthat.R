library(testthat)
library(statnipokladna)

test_check("statnipokladna")
