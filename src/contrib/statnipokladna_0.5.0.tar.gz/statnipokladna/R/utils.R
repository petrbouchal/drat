
openlinks <- function() {
  utils::browseURL("http://monitor.statnipokladna.cz/2019/zdrojova-data/transakcni-data")
  utils::browseURL("http://monitor.statnipokladna.cz/2019/zdrojova-data/ciselniky")
  utils::browseURL("http://monitor.statnipokladna.cz/")
}
